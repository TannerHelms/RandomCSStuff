<?php
$conn->close();
echo "<br>Database Connection Closed";
?>