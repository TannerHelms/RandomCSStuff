<?php
// Dev version
//$servername = "localhost";
//$username = "root";
//$password = "toor";
//$dbname = "DBa1";
//Ops version
$servername="DBa1root.db.9259277.47b.hostedresource.net";
$username="DBa1root";
$password="DBa1@toor";
$dbname="DBa1root";
// Create connection
$conn=new mysqli($servername,$username,$password,$dbname);
?>