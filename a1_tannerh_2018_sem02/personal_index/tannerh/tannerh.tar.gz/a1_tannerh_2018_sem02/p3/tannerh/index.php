<!DOCTYPE html>
<html>


<head>
<meta charset="utf-8" >
<title>p3 Tanner h</title>
<link href="https://fonts.googleapis.com/css?family=BioRhyme+Expanded" rel="stylesheet">
</head>
<style>
body{
  background-image: url(images/wood1.jpg);
}
h4{
  color: red;
  font-family: 'BioRhyme Expanded', serif;
}
#header {
  grid-area: hd;
  background-color: #CCC;
  background-image: url(images/blue.jpg);
  text-align: center;
  color: red;
  font-family: 'BioRhyme Expanded', serif;
}



#instructions {
  grid-area: instruct;
  background-color: #CCC;
  background-image: url(images/blue.jpg);
}

#footer {
  grid-area: ft;
  background-color: #CCC;
  background-image: url(images/blue.jpg);
}

#master {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-template-rows: 100px auto 200px;
  grid-gap: 10px;
  grid-template-areas:
  'hd       hd      hd'
   'dat     dat     instruct'
  'ft         ft       ft';
}

#data {
  grid-area: dat;
  background-color: #CCC;
  background-image: url(images/blue.jpg);
  color: red;
  font-family: 'BioRhyme Expanded', serif;
  display: grid;
  grid-template-columns: 75% 25%;
  grid-template-rows: auto;
  grid-template-areas:
  'form gallery'


}
#gridData{
  grid-area: form;
}
/*
#firstname, #lastname, #email, #whenithappened, #howlong, #howmany, #aliendescription, #whattheydid, #otherabductions, #frankspotted, #other{
  margin-right: 200px;
  text-align: center;
}
*/
/*
#right{
  text-align: left;
}
*/
#left{
  margin-left: 15%;
}
#right{
margin-left: 15%;
}
#h{
  text-align: center;
}
#middle{
  margin-left: 50%;
}
#submit{
margin-left: 45%;
}
hr{
  width: 70%;
}
#thetommy{
 margin-left: 30%;
}
#theGallery{

  max-height: 500px;
  max-width: 270px;
  overflow-y: scroll;
  margin-top:5%;

}
imageGalley{
margin-top:40%;
}

</style>
<body>

  <div id="master">
    <div id="header">
      <h4>Alien Abduction!!!<br /></h4>
      <h5>By Tanner Helms -- 02/13/2018</h5>
    </div>
    <div id="data">
      <div id="imageGalley">
        <br><br><br><br><br><br>
        <h4>Image Gallery:</h4>
        <div id="theGallery">
      <img src="images/alien02.jpg">
      <img src="images/alien03.jpg">
      <img src="images/alien04.jpg">
      <img src="images/alien05.jpg">
      <img src="images/alien06.jpg">
      <img src="images/alien07.jpeg">
    </div>
      </div>
      <div id="gridData">
        <h4 id="h">Aliens Adbducted Me!</h4>
      <h4 id="h">Alien Abduction form:</h4>
      <span>
      <form method="post" action="php/report.php">
        <label id="left" for="firstname">Firstname:</label><br>
        <input id="right" type="text" id="firstname" name="firstname" /><br /><hr>
        <label id="left" for="lastname">Last name:</label><br>
        <input id="right" type="text" id="lastname" name ="lastname" /><br /><hr>
        <label id="left" for="email">What is your email address?</label><br>
        <input id="right" type ="text" id="email" name="email" /><br /><hr>
        <label id="left" for="whenithappened">When did it happen?</label><br>
        <input  id="right" type="text" id="whenithappened" name ="whenithappened" /><br /><hr>
        <label id="left" for="howlong">How long were you gone?</label><br>
        <input  id="right" type="text" id="howlong" name ="howlong" /><br /><hr>
        <label id="left" for="howmany">How many did you see?</label><br>
        <input  id="right" type="text" id="howmany" name ="howmany" /><br /><hr>
        <label id="left" for="aliendescription">Describe Them:</label><br>
        <input  id="right" type="text" id="aliendescription" name ="aliendescription" /><br /><hr>
        <label id="left" for="whattheydid">What did they do to you?</label><br>
        <input  id="right" type="text" id="whattheydid" name ="whattheydid" /><br /><hr>
        <label id="left" for="otherabductions">Did you see any other abductions?</label><br>
        <input  id="right" type="text" id="otherabductions" name ="otherabductions" /><br />
        <span id="middle">Yes</span><input  type="radio" id="otherabductions" name="otherabductions" value="yes" />
      No<input type="radio" id="otherabductions" name="otherabductions" value="no" /><br /><hr>
        <label id="left" for="frankspotted">Did you see Tommy?</label><br />
      <span id="middle">Yes</span><input type="radio" id="frankspotted" name="frankspotted" value="yes" />
    No<input type="radio" id="frankspotted" name="frankspotted" value="no" /><br />
        <img id="thetommy" src="images/alien.jpg" alt="Frank"><br />
        <label id="left" for="other">Anything else you want to add?</label>
        <textarea  id="right"  name="other"></textarea><br /><hr>
        <input id="submit" type="submit" value="Report Adbduction" name="submit" /><br><br>

      </form>
    </span>
    </div>
    </div>
    <div id="instructions">
      <h4>instructions: instructions, or general info -- catch all</h4>
      <a href="docs/firstTest.txt">Create an HTML form. read & verify with php</a>

    </div>
    <div id="footer">
      <h4>Logos</h4>
      <img src="images/eagle.png" height="100px" alt="Frank">
      <img src="images/westada.png"  height="100px" alt="Frank">
      <img src="images/centennial.png"  height="100px" alt="Frank">

    </div>
  </div>


</body>

<html>


</html>
